package resourceplayer;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class WatchTower extends Robot {

    public WatchTower(RobotController rc){
        super(rc);
    }

    public void run() throws GameActionException {
        super.run();

        // Do stuff
    }

}
