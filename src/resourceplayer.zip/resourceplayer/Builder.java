package resourceplayer;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Builder extends Robot {

    public Builder(RobotController rc){
        super(rc);
    }

    public void run() throws GameActionException {
        super.run();

        // Do stuff
    }

}
