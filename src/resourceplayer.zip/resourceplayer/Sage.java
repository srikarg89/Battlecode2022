package resourceplayer;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Sage extends Robot {

    public Sage(RobotController rc){
        super(rc);
    }

    public void run() throws GameActionException {
        super.run();
        // Do stuff
    }

}
