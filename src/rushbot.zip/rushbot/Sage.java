package rushbot;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Sage extends Robot {

    public Sage(RobotController rc) throws GameActionException {
        super(rc);
    }

    public void run() throws GameActionException {
        super.run();
        // Do stuff
    }

}
