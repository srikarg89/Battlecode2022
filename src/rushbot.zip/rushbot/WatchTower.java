package rushbot;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class WatchTower extends Robot {

    public WatchTower(RobotController rc) throws GameActionException {
        super(rc);
    }

    public void run() throws GameActionException {
        super.run();

        // Do stuff
    }

}
